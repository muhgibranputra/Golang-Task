package main

import "fmt"

func main() {
	var hasil, y1, y2, y3, y4 bool
	var x1, x2, x3, x4 int
	fmt.Scan(&x1, &x2, &x3, &x4)
	y1 = x1%400 == 0 || x1%4 == 0 && x1%100 != 0
	y2 = x2%400 == 0 || x2%4 == 0 && x2%100 != 0
	y3 = x3%400 == 0 || x3%4 == 0 && x3%100 != 0
	y4 = x4%400 == 0 || x4%4 == 0 && x4%100 != 0
	hasil = y1 && y2 && y3 && y4
	fmt.Print(hasil)
}
