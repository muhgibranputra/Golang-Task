package main

import "fmt"

func main() {
	var a, b, c string
	var hasil bool
	fmt.Scan(&a, &b, &c)
	hasil = a == b || a == c || b == c
	fmt.Print(hasil)
}
