package main

import "fmt"

func main() {
	var hasil float64
	var x1, x2, y1, y2 int
	fmt.Scan(&x1, &y1, &x2, &y2)
	hasil = (float64(y1 - y2)) / (float64(x1 - x2))
	fmt.Print(hasil)
	fmt.Scan(&x1, &y1, &x2, &y2)
	hasil = (float64(y1 - y2)) / (float64(x1 - x2))
	fmt.Print(hasil)
	fmt.Scan(&x1, &y1, &x2, &y2)
	hasil = (float64(y1 - y2)) / (float64(x1 - x2))
	fmt.Print(hasil)
}
