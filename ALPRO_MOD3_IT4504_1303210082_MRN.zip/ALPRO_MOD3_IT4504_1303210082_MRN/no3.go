package main

import "fmt"

func main() {
	var gram, hasil1, hasil2, hasil3 float64
	fmt.Scan(&gram)
	hasil1 = gram / 1000
	hasil2 = gram / 453.592
	hasil3 = gram / 28.3495
	fmt.Print(hasil1, hasil2, hasil3)
	fmt.Scan(&gram)
	hasil1 = gram / 1000
	hasil2 = gram / 453.592
	hasil3 = gram / 28.3495
	fmt.Print(hasil1, hasil2, hasil3)
	fmt.Scan(&gram)
	hasil1 = gram / 1000
	hasil2 = gram / 453.592
	hasil3 = gram / 28.3495
	fmt.Print(hasil1, hasil2, hasil3)
	fmt.Scan(&gram)
	hasil1 = gram / 1000
	hasil2 = gram / 453.592
	hasil3 = gram / 28.3495
	fmt.Print(hasil1, hasil2, hasil3)
}
