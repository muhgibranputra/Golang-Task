package main

import "fmt"

func main() {
	var x, n, jumlah int
	var rata float64

	fmt.Scan(&x)
	jumlah = 0
	n = 0
	for x != -1 {
		n = n + 1
		jumlah = jumlah + x
		fmt.Scan(&x)
	}
	if n == 0 {
		rata = 0.0
	} else {
		rata = float64(jumlah) / float64(n)
		fmt.Print(rata)
	}
}
