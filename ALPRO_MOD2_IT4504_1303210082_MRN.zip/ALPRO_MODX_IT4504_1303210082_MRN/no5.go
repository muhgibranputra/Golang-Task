package main

import "fmt"

func main() {
	var string string
	fmt.Scanln(&string)
	for string != "selesai" {
		fmt.Println(string)
		fmt.Scanln(&string)
	}
}
