package main

import "fmt"

func main() {
	var r, luas int
	fmt.Scan(&r)
	luas = r * 22 / 7
	fmt.Print("Luas lingkaran dengan jari-jari = ", r, " adalah ", luas)
}
