package main

import "fmt"

func main() {
	var a string
	var b, c, hasil int
	fmt.Scan(&a, &b, &c)
	hasil = b + c
	fmt.Print("Kata = ", a)
	fmt.Print("Jumlah = ", hasil)
}
