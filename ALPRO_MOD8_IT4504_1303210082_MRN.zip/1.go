package main

import "fmt"

func main() {
	var d1, d2, i int64

	i = 0
	fmt.Scan(&d1, &d2)
	if d1%2 == 1 && d2%2 == 1 {
		i = i + 1
	}
	for d1 == 1 || (d1%2 != 0 && d2%2 != 0) {
		fmt.Scan(&d1, &d2)
		if d1%2 == 1 && d2%2 == 1 {
			i = i + 1
		}
	}
	fmt.Print(i)
}
