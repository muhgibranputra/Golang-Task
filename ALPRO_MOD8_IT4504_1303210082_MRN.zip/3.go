package main

import "fmt"

func fpb(a, b int64) int64 {
	if b == 0 {
		return a
	} else {
		return fpb(b, a%b)
	}
}
func kpk(a, b int64) int64 {
	return a / fpb(a, b) * b
}
func main() {
	var a, b int64
	fmt.Scan(&a, &b)
	fmt.Print("KPK dari ", a, " dan ", b, " adalah ", kpk(a, b))
}
