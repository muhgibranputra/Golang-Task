package main

import "fmt"

func main() {
	var n, a1, a2, a3, b1, b2, b3, total1, total2 int
	fmt.Scan(&n)
	for i := 0; i < n; i++ {
		fmt.Scan(&a1, &a2, &a3, &b1, &b2, &b3)
		total1 = total1 + (a1 + a2 + a3)
		total2 = total2 + (b1 + b2 + b3)

	}
	fmt.Print("Petinju A:", total1, " dan petinju B:", total2)
	if total1 > total2 {
		fmt.Print("\n Pemenang adalah petinju A")
	} else if total2 > total1 {
		fmt.Print("Pemenang adalah petinju B")
	}
}
