package main

import "fmt"

func main() {
	var n, i, x, y, neg, pos int
	fmt.Scanln(&n)
	i = 1
	for i <= n {
		fmt.Scanln(&x, &y)
		if x < 0 {
			neg = neg + x
		} else {
			pos = pos + x
		}
		if y < 0 {
			neg = neg + y
		} else {
			pos = pos + y
		}
		i++
	}
	fmt.Println("Negative: ", neg)
	fmt.Println("Positive: ", pos)
}
