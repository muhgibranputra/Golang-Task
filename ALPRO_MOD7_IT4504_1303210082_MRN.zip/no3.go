package main

import (
	"fmt"
)

func pangkat(a, b int) int {
	var i, hasil int
	i = 1
	hasil = 1
	for i <= b {
		hasil = hasil * a
		i++
	}
	return hasil
}
func konversi(biner int, desimal *int) {
	var bilterakhir, jumlah, i int
	for biner > 0 {
		bilterakhir = biner % 10
		jumlah = jumlah + bilterakhir*pangkat(2, i)
		biner = biner / 10
		i++
	}
	*desimal = jumlah
}
func main() {
	var bln, des int
	fmt.Scanln(&bln)
	konversi(bln, &des)
	fmt.Println(des)
}
