package main

import "fmt"

func main() {
	var penurunan, i, pengunjung, jumlahpengunjung, pengunjungkemarin int
	var rata float64
	i = 1
	for penurunan < 3 {
		fmt.Print("Hari ", i, ": ")
		fmt.Scanln(&pengunjung)
		for pengunjung < 0 || pengunjung > 100 {
			fmt.Print("Hari ", i, ": ")
			fmt.Scanln(&pengunjung)
		}
		jumlahpengunjung = jumlahpengunjung + pengunjung
		if pengunjungkemarin > pengunjung {
			penurunan = penurunan + 1
		} else {
			penurunan = 0
		}
		pengunjungkemarin = pengunjung
		i++
	}
	rata = float64(jumlahpengunjung) / float64(i-1)
	fmt.Println("Museum buka selama ", i-1, "Hari")
	fmt.Printf("Rata rata %.2f pengunjung", rata, "orang")
}
