package main

import "fmt"

func main() {
	var b, i, faktor int
	var status bool
	fmt.Scanln(&b)
	fmt.Print("factor: ")
	i = 1
	for i <= b {
		if b%i == 0 {
			fmt.Print(i, " ")
			faktor++
		}
		i++
	}
	status = faktor == 2
	fmt.Println("")
	fmt.Print("Prima: ", status)
}
