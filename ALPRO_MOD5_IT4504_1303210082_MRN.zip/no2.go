package main

import "fmt"

func main() {
	var kg, gram, berat, u, d, total int
	fmt.Print("Berat parsel (gram): ")
	fmt.Scanln(&berat)
	kg = berat / 1000
	gram = berat % 1000
	u = kg * 10000
	if kg > 10 {
		d = 0
	} else if gram < 500 {
		d = gram * 15
	} else {
		d = gram * 5
	}
	total = u + d
	fmt.Println("Detail biaya: ", kg, "kg", gram, "gr")
	fmt.Println("Detail biaya: ", u, " + Rp.", d)
	fmt.Println("Total biaya: Rp. ", total)
}
