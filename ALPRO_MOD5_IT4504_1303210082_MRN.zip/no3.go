package main

import "fmt"

func main() {
	var mk, i, sks, jumlahsks, jumlah int
	var nilai string
	var ips float64
	fmt.Scanln(&mk)
	i = 1
	for i <= mk {
		fmt.Scanln(&nilai, &sks)
		for (nilai != "A" && nilai != "B" && nilai != "C" && nilai != "D" && nilai != "E") || sks < 1 {
			fmt.Scanln(&nilai, &sks)
		}
		jumlahsks = jumlahsks + sks
		if nilai == "A" {
			jumlah = jumlah + 4*sks
		} else if nilai == "B" {
			jumlah = jumlah + 3*sks
		} else if nilai == "C" {
			jumlah = jumlah + 2*sks
		} else if nilai == "E" {
			jumlah = jumlah + 1*sks
		}
		i++
	}
	ips = float64(jumlah) / float64(jumlahsks)
	fmt.Println(ips)
}
