package main

import "fmt"

type tabInt [1000000]int

func sort(t *tabInt, n int) {
	var min, temp int

	for i := 1; i < n; i++ {
		min = i - 1
		for j := i; j < n; j++ {
			if t[min] > t[j] {
				min = j
			}
		}
		temp = t[i-1]
		t[i-1] = t[min]
		t[min] = temp

	}
}
func median(t tabInt, n int) float64 {
	if n%2 != 0 {
		return float64(t[n/2])
	} else {
		return (float64(t[(n-1)/2]) + float64(t[(n/2)])) / 2.0
	}
}
func main() {
	var input, n int
	var data tabInt

	n = 0
	fmt.Scan(&input)
	for input != -5313541 {
		if input == 0 {
			sort(&data, n)
			fmt.Println(median(data, n))
		} else {
			data[n] = input
			n++
		}
		fmt.Scan(&input)
	}
}
