package main

import "fmt"

func findFactorial(n int, result *int) {
	*result = 1
	for i := 1; i <= n; i++ {
		*result *= i
	}
}

func permutation(n int, r int) int {
	var nF, nrF, permutasi int
	findFactorial(n, &nF)    //pembilang (n)
	findFactorial(n-r, &nrF) //penyebut (n-r)
	permutasi = nF / nrF

	return permutasi
}

func combination(n int, r int) int {
	var nF, nrF, rF, kombinasi int

	findFactorial(n, &nF)    //pembilang (n)
	findFactorial(r, &rF)    //penyebut (r)
	findFactorial(n-r, &nrF) //penyebut (n-r)
	kombinasi = nF / (rF * nrF)

	return kombinasi
}

func main() {
	var a, b, c, d int
	var p1, c1, p2, c2 int

	fmt.Scan(&a, &b, &c, &d)
	p1 = permutation(a, c)
	c1 = combination(a, c)
	p2 = permutation(b, d)
	c2 = combination(b, d)

	fmt.Println(p1, c1)
	fmt.Println(p2, c2)
}
