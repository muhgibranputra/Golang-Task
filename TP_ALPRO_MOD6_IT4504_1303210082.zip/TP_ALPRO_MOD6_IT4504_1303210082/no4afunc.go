package main

import (
	"fmt"
	"math"
)

func maxmin(a, b, c, d float64) (float64, float64) {
	var bil1, bil2, bil3, bil4, hasil1, hasil2 float64
	bil2 = math.Max(a, c)
	bil3 = math.Min(a, c)
	bil1 = math.Max(b, d)
	bil4 = math.Min(b, d)

	hasil1 = math.Max(bil2, bil1)
	hasil2 = math.Min(bil3, bil4)

	return hasil2, hasil1
}

func main() {
	var a1, b1, c1, d1 float64
	fmt.Scanln(&a1, &b1, &c1, &d1)
	fmt.Println(maxmin(a1, b1, c1, d1))
}
