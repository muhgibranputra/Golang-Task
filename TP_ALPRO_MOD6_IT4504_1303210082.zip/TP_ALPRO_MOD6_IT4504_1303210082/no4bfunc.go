package main

import "fmt"

func biner(n int) string {
	var s string
	s = " "
	for n > 0 {
		if n%2 == 0 {
			s = "0" + s
		} else {
			s = "1" + s
		}
		n = n / 2
	}
	return s
}

func main() {
	var angka int
	fmt.Scan(&angka)
	fmt.Println(biner(angka))
}
