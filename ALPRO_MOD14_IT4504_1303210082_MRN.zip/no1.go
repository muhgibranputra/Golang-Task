package main

import "fmt"

// declaration of global variable for machine character
var pita string
var CC byte
var EOP bool
var indeks int

// declaration of START and ADV procedure
func START() {
	/* I.S. pita telah berisi oleh sekumpulan karakter yang diakhiri oleh hashtag '.'
	   F.S. CC berisi karakter pertama dari pita, EOP bernilai true apabila CC adalah '.', false untuk sebaliknya*/
	indeks = 0
	CC = pita[indeks]
	EOP = CC == '.'
}

func ADV() {
	/* I.S. EOP bernilai false
	   F.S. CC berisi karakter berikutnya dari CC pada pita karakter saat ini, EOP bernilai true apabila CC adalah '.', false untuk sebaliknya*/
	indeks++
	CC = pita[indeks]
	EOP = CC == '.'
}

func DIGIT() bool {
	/* mengembalikan true apabila CC adalah digit '0', '1', '2', ..., atau '9', false untuk kemungkinan yang lain*/
	return CC >= '0' && CC <= '9'
}

func main() {
	// declaration of variable
	var valid bool = false
	// input pita karakter
	fmt.Scan(&pita)
	// nyalakan mesin
	START()
	// proses pita
	if CC == 'I' {
		ADV()
		if CC == 'T' {
			ADV()
			if CC == '-' {
				ADV()
				for DIGIT() {
					ADV()
				}
				if CC == '-' {
					ADV()
					if DIGIT() {
						for DIGIT() {
							ADV()
						}
						valid = EOP
					}
				}
			}
		}
	}
	fmt.Println(valid)
}
