package main

import "fmt"

func main() {
	var hari, bulan, hari1, bulan1 string
	var tanggal, tahun, tanggal1, tahun1, ganti int
	// pembacaan masukan
	ganti = angkaBulan(bulan1)
	fmt.Scanln(&hari, &tanggal, &bulan, &tahun)
	for hari == "sabtu" || hari == "minggu" || tanggal == 29 && !kabisat(tahun) == false {
		fmt.Println("waktu salah, silahkan masukkan kembali waktu pengajuan:")
		fmt.Scanln(&hari, &tanggal, &bulan, &tahun)
	}
	// panggil subprogram untuk penentuan tanggal pengambilan
	pengambilan(tanggal, angkaBulan(bulan), tahun, hari, &tanggal1, &ganti, &tahun1, &hari1)
	// tampilkan tanggal pengambilan visa
	fmt.Println(hari1, tanggal1, bulanAngka(ganti), tahun1)
}

func kabisat(tahun int) bool {
	// Mengembalikan true apabila tahun adalah kabisat, false apabila sebaliknya.
	var cek1 bool
	cek1 = tahun%400 == 0 || tahun%4 == 0 && tahun%100 != 0
	return cek1
}

func angkaBulan(bulan string) int {
	/* Mengembalikan angka berdasarkan urutan nama bulan pada kalender masehi (1 hingga 12).
	   0 untuk bulan yang tidak valid. Asumsi nama bulan ditulis dengan huruf kecil semua. Contoh: "januari" menjadi 1 */
	var cek2 int
	if bulan == "januari" {
		cek2 = 1
	} else if bulan == "februari" {
		cek2 = 2
	} else if bulan == "maret" {
		cek2 = 3
	} else if bulan == "april" {
		cek2 = 4
	} else if bulan == "mei" {
		cek2 = 5
	} else if bulan == "juni" {
		cek2 = 6
	} else if bulan == "juli" {
		cek2 = 7
	} else if bulan == "agustus" {
		cek2 = 8
	} else if bulan == "september" {
		cek2 = 9
	} else if bulan == "oktober" {
		cek2 = 10
	} else if bulan == "november" {
		cek2 = 11
	} else if bulan == "desember" {
		cek2 = 12
	}
	return cek2
}

func bulanAngka(angka int) string {
	/* Mengembalikan nama bulan berdasarkan urutan angka bulan pada kalender masehi (1 hingga 12).
	   "invalid" untuk bulan yang tidak valid. Asumsi nama bulan ditulis dengan huruf kecil semua. Contoh: 1 menjadi "januari" */
	var cek3 string
	if angka == 1 {
		cek3 = "januari"
	} else if angka == 2 {
		cek3 = "februari"
	} else if angka == 3 {
		cek3 = "maret"
	} else if angka == 4 {
		cek3 = "april"
	} else if angka == 5 {
		cek3 = "mei"
	} else if angka == 6 {
		cek3 = "juni"
	} else if angka == 7 {
		cek3 = "juli"
	} else if angka == 8 {
		cek3 = "agustus"
	} else if angka == 9 {
		cek3 = "september"
	} else if angka == 10 {
		cek3 = "oktober"
	} else if angka == 11 {
		cek3 = "november"
	} else if angka == 12 {
		cek3 = "desember"
	}
	return cek3
}

func jumlahHari(bulan, tahun int) int {
	/* Mengembalikan jumlah hari berdasarkan bulan dan tahun yang terdefinisi,
	   hati-hati pada bulan februari pada saat kabisat. -1 apabila bulan tidak valid */
	var cek4 int
	if kabisat(tahun) {
		if bulan == 1 || bulan == 3 || bulan == 5 || bulan == 7 || bulan == 8 || bulan == 10 || bulan == 12 {
			cek4 = 31
		} else if bulan == 4 || bulan == 6 || bulan == 9 || bulan == 11 {
			cek4 = 30
		} else if bulan == 2 {
			cek4 = 29
		}
	} else {
		if bulan == 1 || bulan == 3 || bulan == 5 || bulan == 7 || bulan == 8 || bulan == 10 || bulan == 12 {
			cek4 = 31
		} else if bulan == 4 || bulan == 6 || bulan == 9 || bulan == 11 {
			cek4 = 30
		} else if bulan == 2 {
			cek4 = 28
		}
	}
	return cek4
}

func mencariDurasi(hari1 string, hari2 *string, durasi *int) {
	/* I.S. terdefinisi hari1 yang menyatakan hari pengajuan string, asumsi huruf kecil semua
	   F.S. hari2 berisi hari pengambilan dan durasi berisi lama pembuatan visa, karena sabtu dan minggu tidak dihitung */
	if hari1 == "senin" {
		*durasi = 2
		*hari2 = "rabu"
	} else if hari1 == "selasa" {
		*durasi = 2
		*hari2 = "kamis"
	} else if hari1 == "rabu" {
		*durasi = 2
		*hari2 = "jumat"
	} else if hari1 == "kamis" {
		*durasi = 4
		*hari2 = "senin"
	} else if hari1 == "jumat" {
		*durasi = 4
		*hari2 = "selasa"
	}
}
func pengambilan(tanggal1, bulan1, tahun1 int, hari1 string, tanggal2, bulan2, tahun2 *int, hari2 *string) {
	/* I.S. terdefinisi waktu pengajuan visa, yaitu tanggal1, bulan1, tahun1 dan hari1
	   F.S. tanggal2, bulan2, tahun2 dan hari2 berisi waktu pengambilan visa */
	// tentukan durasi, hari pengambilan, dan jumlah hari pada bulan pengajuan
	var durasi, lamahari int
	mencariDurasi(hari1, hari2, &durasi)
	lamahari = jumlahHari(bulan1, tahun1)
	// dapatkan tanggal pengambilan, asumsi bulan pengambilan dan tahun pengambilan sama dengan waktu pengajuan
	if (durasi + tanggal1) > lamahari {
		*tanggal2 = (durasi + tanggal1) - lamahari
		*bulan2 = bulan1 + 1
	} else {
		*tanggal2 = durasi + tanggal1
		*bulan2 = bulan1
	}
	// cek apabila tanggal pengambilan melebihi lama hari, update tanggal dan bulan pengambilan dengan yang seharusnya
	// cek apabila bulan pengambilan melebihi 12, update dengan bulan dan tahun pengambilan yang seharusnya
	if *bulan2 > 12 {
		*bulan2 = *bulan2 - 12
		*tahun2 = tahun1 + 1
	} else {
		*tahun2 = tahun1
	}
}
