package main

import "fmt"

func main() {
	var i, n int
	var status, k1, k2, k3, k4 bool
	i = 1
	status = true
	fmt.Scanln(&n)
	for i <= n && status {
		fmt.Scanln(&k1, &k2, &k3, &k4)
		status = k1 && k2 && k3 && k4
		i = i + 1
	}
	fmt.Print(status)
}
