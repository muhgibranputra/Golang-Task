package main

import "fmt"

func main() {
	var hasil, n, a, r, i int
	fmt.Scan(&n, &a, &r)
	fmt.Print("0")
	i = 1
	for i <= n {
		hasil = i * r * a
		fmt.Print(" + ", hasil)
		i = i + 1
	}
}
