package main

import "fmt"

func main() {
	var n, x, jumlah, i int
	fmt.Scanln(&n)
	i = 1
	for i <= n {
		fmt.Scanln(&x)
		for x < 0 || x > 9 {
			fmt.Scanln(&x)
		}
		jumlah = jumlah + x
		i = i + 1
	}
	fmt.Print(jumlah)
}
