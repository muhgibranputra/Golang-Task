package main

import "fmt"

func main() {
	var bil, bil1, bil2 int
	var status bool
	fmt.Scanln(&bil)
	bil1 = bil % 10
	bil = bil / 10
	bil2 = bil % 10
	status = true
	for bil > 0 && status {
		status = bil2-bil1 == 1 || bil1-bil2 == 1
		bil1 = bil % 10
		bil = bil / 10
		bil2 = bil % 10
	}
	fmt.Print(status)
}
